`ifndef _CANFD_SCOREBOARD_SV_
`define _CANFD_SCOREBOARD_SV_

`include "canfd_function_coverage.sv"

//=========================================================================
// canfd_scoreboard: 完整的 CANFD 验证计分板
//   双 FIFO 并行处理 + Reference Model 比对 + 统计报告
//=========================================================================
class canfd_scoreboard extends uvm_scoreboard;

    canfd_config     canfd_cfg;
    canfd_ref_model  ref_model;

    // TLM FIFO
    uvm_analysis_fifo #(canphy_trans)    canphy_analysis_fifo;
    uvm_analysis_fifo #(axi4lite_trans)  axi4lite_analysis_fifo;

    // 功能覆盖率实例
    `ifdef COVERAGE_CANPHY
    FeatureListNum_CANPHY  canphy_cov;
    `endif
    `ifdef COVERAGE_AXI4LITE
    FeatureListNum_AXI4LITE  axi4lite_cov;
    `endif

    // 统计
    int  canphy_tx_count = 0;
    int  canphy_rx_count = 0;
    int  axi4lite_wr_count = 0;
    int  axi4lite_rd_count = 0;
    int  pass_count = 0;
    int  fail_count = 0;
    int  mismatch_count = 0;

    `uvm_component_utils(canfd_scoreboard)

    function new(string name="canfd_scoreboard", uvm_component parent=null);
        super.new(name, parent);
    endfunction

    virtual function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        canphy_analysis_fifo   = new("canphy_analysis_fifo", this);
        axi4lite_analysis_fifo = new("axi4lite_analysis_fifo", this);
        ref_model = canfd_ref_model::type_id::create("ref_model", this);

        `ifdef COVERAGE_CANPHY
        canphy_cov = new();
        `endif
        `ifdef COVERAGE_AXI4LITE
        axi4lite_cov = new();
        `endif
    endfunction

    virtual task run_phase(uvm_phase phase);
        super.run_phase(phase);
        @(posedge canfd_vif.rstn);
        if (!uvm_config_db#(canfd_config)::get(this, "", "canfd_config", canfd_cfg))
            `uvm_error(get_type_name(), "failed to get config")

        fork
            // CAN PHY 帧处理线程
            forever begin
                canphy_trans tr;
                canphy_analysis_fifo.get(tr);
                process_canphy_tr(tr);
            end
            // AXI4-Lite 事务处理线程
            forever begin
                axi4lite_trans tr;
                axi4lite_analysis_fifo.get(tr);
                process_axi4lite_tr(tr);
            end
            // 时间戳滴答线程
            forever begin
                @(posedge canfd_vif.clk);
                ref_model.tick();
            end
        join
    endtask

    //---------------------------------------------------------------------
    // process_canphy_tr: CAN PHY 帧处理
    //   判断 TX/RX 方向，与 ref_model 比对
    //---------------------------------------------------------------------
    virtual function void process_canphy_tr(canphy_trans tr);
        `uvm_info(get_type_name(), $sformatf("SCB CANPHY: %s", tr.convert2string()), UVM_HIGH)

        // 覆盖率采样
        `ifdef COVERAGE_CANPHY
        canphy_cov.sample(tr);
        `endif

        // 判断帧来源: DUT TX (can_phy_tx 驱动) vs 外部注入 (can_phy_rx 驱动)
        // 简化: 所有捕获的帧都视为 DUT TX (monitor 只看 tx 信号)
        // 实际应通过方向标志区分

        if (tr.frame_type == ERROR_FRAME) begin
            `uvm_info(get_type_name(), "Detected ERROR FRAME on bus", UVM_MEDIUM)
            return;
        end

        // TX 方向: 与 ref_model 期望发送帧比对
        canphy_trans  exp_tr;
        exp_tr = ref_model.get_expected_tx_frame();
        if (exp_tr != null) begin
            compare_tx_frame(exp_tr, tr);
            // 模型侧标记已发送
            ref_model.process_tx_arbitration();
            canphy_tx_count++;
        end

        // 同时作为 RX 方向: 模型接收此帧
        ref_model.on_can_frame_received(tr);
        canphy_rx_count++;
    endfunction

    //---------------------------------------------------------------------
    // compare_tx_frame: 比对期望 TX 帧与实际 TX 帧
    //---------------------------------------------------------------------
    virtual function void compare_tx_frame(canphy_trans exp, canphy_trans act);
        bit match = 1;

        if (exp.frame_type != act.frame_type) begin
            `uvm_error(get_type_name(), $sformatf(
                "TX frame_type mismatch: exp=%s act=%s", exp.frame_type.name(), act.frame_type.name()))
            match = 0;
        end
        if (exp.can_id !== act.can_id) begin
            `uvm_error(get_type_name(), $sformatf(
                "TX ID mismatch: exp=0x%07h act=0x%07h", exp.can_id, act.can_id))
            match = 0;
        end
        if (exp.dlc !== act.dlc) begin
            `uvm_error(get_type_name(), $sformatf(
                "TX DLC mismatch: exp=%0d act=%0d", exp.dlc, act.dlc))
            match = 0;
        end
        if (exp.fdf !== act.fdf) begin
            `uvm_error(get_type_name(), $sformatf(
                "TX FDF mismatch: exp=%b act=%b", exp.fdf, act.fdf))
            match = 0;
        end
        if (exp.brs !== act.brs) begin
            `uvm_error(get_type_name(), $sformatf(
                "TX BRS mismatch: exp=%b act=%b", exp.brs, act.brs))
            match = 0;
        end

        // 数据比对 (非远程帧)
        if (!exp.rtr && exp.data.size() > 0) begin
            if (exp.data.size() != act.data.size()) begin
                `uvm_error(get_type_name(), $sformatf(
                    "TX data size mismatch: exp=%0d act=%0d", exp.data.size(), act.data.size()))
                match = 0;
            end else begin
                foreach (exp.data[i]) begin
                    if (exp.data[i] !== act.data[i]) begin
                        `uvm_error(get_type_name(), $sformatf(
                            "TX data[%0d] mismatch: exp=0x%02h act=0x%02h", i, exp.data[i], act.data[i]))
                        match = 0;
                    end
                end
            end
        end

        if (match) begin
            pass_count++;
            `uvm_info(get_type_name(), "TX frame match ✓", UVM_HIGH)
        end else begin
            fail_count++;
            mismatch_count++;
        end
    endfunction

    //---------------------------------------------------------------------
    // process_axi4lite_tr: AXI4-Lite 事务处理
    //   写操作: 更新 ref_model 状态
    //   读操作: 比对读回值与 ref_model 期望值
    //---------------------------------------------------------------------
    virtual function void process_axi4lite_tr(axi4lite_trans tr);
        `uvm_info(get_type_name(), $sformatf("SCB AXI4LITE: %s", tr.convert2string()), UVM_HIGH)

        `ifdef COVERAGE_AXI4LITE
        axi4lite_cov.sample(tr);
        `endif

        if (tr.dir == AXI4LITE_WRITE) begin
            axi4lite_wr_count++;
            // 更新参考模型
            ref_model.write_reg(tr.addr, tr.data);

            // TX 消息空间写入
            if (tr.addr >= 16'h0100 && tr.addr <= 16'h1FFF) begin
                int buf_idx = (tr.addr - 16'h0100) / 16;  // 每缓冲器16 words
                int offset  = (tr.addr - 16'h0100) % 16;
                ref_model.write_tx_buf(buf_idx, offset, tr.data);
            end
        end else begin
            axi4lite_rd_count++;
            // 比对读回值
            logic [31:0] exp_data;
            exp_data = ref_model.read_reg(tr.addr);
            if (tr.addr <= 16'h00FF) begin
                if (tr.data !== exp_data) begin
                    // ECR/SR/ISR 等动态寄存器允许差异 (由总线活动驱动)
                    if (tr.addr != 16'h0010 && tr.addr != 16'h0018 && tr.addr != 16'h001C) begin
                        `uvm_error(get_type_name(), $sformatf(
                            "Reg read mismatch @0x%04h: exp=0x%08h got=0x%08h",
                            tr.addr, exp_data, tr.data))
                        fail_count++;
                    end
                end else begin
                    pass_count++;
                end
            end
        end

        // 响应码检查
        if (tr.addr >= 16'h8000 && tr.resp != AXI_RESP_DECERR) begin
            `uvm_error(get_type_name(), $sformatf(
                "Expected DECERR for addr=0x%08h, got resp=%0d", tr.addr, tr.resp))
            fail_count++;
        end
        if (tr.addr < 16'h8000 && tr.resp != AXI_RESP_OKAY) begin
            `uvm_error(get_type_name(), $sformatf(
                "Unexpected error resp=%0d for addr=0x%08h", tr.resp, tr.addr))
            fail_count++;
        end
    endfunction

    virtual function void report_phase(uvm_phase phase);
        super.report_phase(phase);
        `uvm_info(get_type_name(),
            $sformatf("\n========================================\n  SCOREBOARD REPORT\n========================================\n  CANPHY TX frames:    %0d\n  CANPHY RX frames:    %0d\n  AXI4LITE writes:     %0d\n  AXI4LITE reads:      %0d\n  PASS:                %0d\n  FAIL:                %0d\n  Mismatches:          %0d\n========================================",
                canphy_tx_count, canphy_rx_count,
                axi4lite_wr_count, axi4lite_rd_count,
                pass_count, fail_count, mismatch_count), UVM_LOW)
    endfunction

endclass : canfd_scoreboard

`endif
