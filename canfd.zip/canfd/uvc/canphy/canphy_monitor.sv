`ifndef _CANPHY_MONITOR_SV_
`define _CANPHY_MONITOR_SV_

//=========================================================================
// canphy_monitor: CAN PHY 帧级监控器
//   职责: 采样 can_phy_tx 信号，解析出完整的 CAN/CAN FD 帧
//   通过 analysis_port 发送给 scoreboard
//=========================================================================
class canphy_monitor extends uvm_monitor;

    virtual canphy_vif       vif;
    canphy_config            cfg;
    canphy_trans             tr;

    uvm_analysis_port #(canphy_trans)  mon_analysis_port;
    `uvm_register_cb(canphy_monitor, canphy_monitor_callback)

    `uvm_component_utils(canphy_monitor)

    function new(string name="canphy_monitor", uvm_component parent=null);
        super.new(name, parent);
    endfunction

    virtual function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        mon_analysis_port = new("mon_analysis_port", this);
    endfunction

    virtual function void connect_phase(uvm_phase phase);
        super.connect_phase(phase);
        if (!uvm_config_db#(virtual canphy_vif)::get(this, "", "canphy_vif", vif))
            `uvm_fatal("NOVIF", "canphy_vif not set for monitor")
    endfunction

    //---------------------------------------------------------------------
    // run_phase: 持续监控总线
    //   检测 SOF (下降沿: 从隐性 1 到显性 0) → 开始接收帧
    //---------------------------------------------------------------------
    virtual task run_phase(uvm_phase phase);
        bit prev_tx = 1'b1;

        forever begin
            @(posedge vif.clk);

            // 检测 SOF: 总线从隐性→显性
            if (prev_tx === 1'b1 && vif.can_phy_tx === 1'b0) begin
                // 检测到帧起始
                capture_frame();
            end
            prev_tx = vif.can_phy_tx;
        end
    endtask

    //---------------------------------------------------------------------
    // capture_frame: 捕获并解析一个完整 CAN 帧
    //   简化版: 基于位采样，不做完整的位填充/CRC 解析
    //   生产环境应使用商业 VIP 或完整的 BFM
    //---------------------------------------------------------------------
    virtual task capture_frame();
        bit bit_queue[$];
        bit sampled_bit;
        int bit_time = cfg.bit_time_ns;
        int cycles_per_bit = bit_time / 20;

        // 采样 SOF (已检测到)
        bit_queue.push_back(1'b0);

        // 持续采样直到检测到 EOF (7 个连续隐性位)
        // 简化: 采集固定数量的位 (实际应检测 EOF)
        int consecutive_recessive = 0;
        int max_bits = 200; // 安全上限

        fork
            begin
                for (int i=0; i<max_bits; i++) begin
                    // 在采样点采样 (TS1 结束处)
                    repeat(cycles_per_bit) @(posedge vif.clk);
                    sampled_bit = vif.can_phy_tx;
                    bit_queue.push_back(sampled_bit);

                    if (sampled_bit == 1'b1) begin
                        consecutive_recessive++;
                        if (consecutive_recessive >= 7) begin
                            // 检测到 EOF
                            disable capture_loop;
                            break;
                        end
                    end else begin
                        consecutive_recessive = 0;
                    end
                end
            end
        join_any

        // 解析位流为帧事务
        parse_frame(bit_queue);
    endtask : capture_frame

    //---------------------------------------------------------------------
    // parse_frame: 将位队列解析为 canphy_trans
    //   简化版: 提取基本字段 (ID, DLC, 部分数据)
    //---------------------------------------------------------------------
    virtual function void parse_frame(ref bit bit_queue[$]);
        canphy_trans frame;
        int idx = 0;
        bit destuffed[];

        // 1. 位去填充
        int same_count = 1;
        bit last_bit;

        if (bit_queue.size() > 0) begin
            destuffed = new[1]; destuffed[0] = bit_queue[0]; idx = 1;
            last_bit = bit_queue[0];

            for (int i=1; i<bit_queue.size() && i<150; i++) begin
                if (bit_queue[i] == last_bit) begin
                    same_count++;
                    if (same_count == 5) begin
                        // 跳过下一个填充位 (如果存在)
                        if (i+1 < bit_queue.size()) i++;
                        same_count = 1;
                        if (i+1 < bit_queue.size()) begin
                            last_bit = bit_queue[i+1];
                            destuffed = new[destuffed.size()+1];
                            destuffed[destuffed.size()-1] = bit_queue[i+1];
                        end
                        continue;
                    end
                end else begin
                    same_count = 1;
                    last_bit = bit_queue[i];
                end
                destuffed = new[destuffed.size()+1];
                destuffed[destuffed.size()-1] = bit_queue[i];
            end
        end

        frame = canphy_trans::type_id::create("frame");

        // 2. 解析帧字段 (从 destuffed 数组)
        int pos = 0;
        if (destuffed.size() < 20) return; // 太短，忽略

        // SOF (1 bit)
        pos = 1;

        // ID (11 bits)
        frame.can_id = 0;
        for (int i=0; i<11 && pos<destuffed.size(); i++)
            frame.can_id[10-i] = destuffed[pos++];

        // RTR (1 bit)
        if (pos < destuffed.size()) frame.rtr = destuffed[pos++];

        // IDE (1 bit)
        if (pos < destuffed.size()) frame.ide = destuffed[pos++];

        if (frame.ide) begin
            // 扩展帧: 18-bit ID + RTR + r1 + r0
            for (int i=0; i<18 && pos<destuffed.size(); i++)
                frame.can_id[17-i] = destuffed[pos++];
            if (pos < destuffed.size()) frame.rtr = destuffed[pos++];
            pos += 2; // r1, r0
        end

        // FDF (1 bit)
        if (pos < destuffed.size()) frame.fdf = destuffed[pos++];

        if (frame.fdf) begin
            // CAN FD: BRS + ESI + DLC(4)
            if (pos < destuffed.size()) frame.brs = destuffed[pos++];
            if (pos < destuffed.size()) frame.esi = destuffed[pos++];
        end else begin
            pos++; // r0
        end

        // DLC (4 bits)
        frame.dlc = 0;
        for (int i=0; i<4 && pos<destuffed.size(); i++)
            frame.dlc[3-i] = destuffed[pos++];

        // 数据段
        int data_bytes = frame.dlc_to_bytes(frame.dlc);
        if (!frame.rtr && data_bytes > 0) begin
            frame.data = new[data_bytes];
            for (int i=0; i<data_bytes && pos+7<destuffed.size(); i++) begin
                for (int j=7; j>=0; j--)
                    frame.data[i][j] = destuffed[pos++];
            end
        end

        // 设置帧类型
        if (frame.fdf)
            frame.frame_type = frame.ide ? CANFD_EXT : CANFD_STD;
        else if (frame.rtr)
            frame.frame_type = frame.ide ? CAN_EXT_REMOTE : CAN_STD_REMOTE;
        else
            frame.frame_type = frame.ide ? CAN_EXT_DATA : CAN_STD_DATA;

        frame.bit_count = destuffed.size();

        `uvm_info(get_type_name(), $sformatf("Captured: %s", frame.convert2string()), UVM_HIGH)
        mon_analysis_port.write(frame);
    endfunction

endclass

`endif
